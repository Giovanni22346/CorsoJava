package src.neotech.prova03;

public class Impiegato {

}
